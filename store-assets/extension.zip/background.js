// 检查事件并发送通知
function checkEvents() {
  chrome.storage.local.get(['events'], (result) => {
    const events = result.events || [];
    const now = new Date().getTime();
    const futureEvents = events.filter(event => event.date > now);
    const nextEvent = futureEvents.sort((a, b) => a.date - b.date)[0];

    // 更新扩展图标上的倒计时
    if (nextEvent) {
      const days = Math.floor((nextEvent.date - now) / (1000 * 60 * 60 * 24));
      // 设置徽章文本
      chrome.action.setBadgeText({ text: String(days) });
      // 设置徽章背景为鲜艳的红色
      chrome.action.setBadgeBackgroundColor({ color: '#E53935' });
      // 设置徽章文字为白色
      chrome.action.setBadgeTextColor({ color: '#FFFFFF' });
    } else {
      // 如果没有事件，清除徽章
      chrome.action.setBadgeText({ text: '' });
    }

    // 检查是否需要发送通知
    events.forEach(event => {
      const timeLeft = event.date - now;
      
      // 当事件还有1天时发送通知
      if (timeLeft > 0 && timeLeft <= 24 * 60 * 60 * 1000) {
        const hours = Math.floor(timeLeft / (1000 * 60 * 60));
        
        chrome.notifications.create(`event-${event.id}`, {
          type: 'basic',
          iconUrl: 'icons/icon128.png',
          title: '倒计时提醒',
          message: `${event.name} 还剩 ${hours} 小时！`,
          priority: 2
        });
      }
    });
  });
}

// 每小时检查一次事件
chrome.alarms.create('checkEvents', {
  periodInMinutes: 60
});

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === 'checkEvents') {
    checkEvents();
  }
});

// 监听存储变化，实时更新徽章
chrome.storage.onChanged.addListener((changes, namespace) => {
  if (namespace === 'local' && changes.events) {
    checkEvents();
  }
});

// 初始化时立即检查一次
checkEvents(); 